const TOWN_DIRECTORY = [
  {
    name: "Vero Beach",
    url: "https://example.com/vero"
  },
  {
    name: "Fort Pierce",
    url: "https://example.com/fort-pierce"
  },
  {
    name: "Stuart",
    url: "https://example.com/stuart"
  }
];

module.exports = { TOWN_DIRECTORY };
